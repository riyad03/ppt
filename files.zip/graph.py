"""Sous-graphe LangGraph « génération de note réglementaire ».

    plan ──▶ render ──▶ qa ──┬── (avertissements & itérations < MAX) ──▶ plan
                             └── ok ──▶ END

Seul le nœud `plan` appelle le modèle. `render` et `qa` sont déterministes, ce
qui rend le pipeline testable et reproductible — indispensable pour un livrable
qui finit dans un dossier d'audit.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated, Any, TypedDict

from langgraph.graph import END, START, StateGraph

from .renderer import render_deck
from .schema import Deck
from .theme import Theme

MAX_ITERATIONS = 2

PROMPT_SYSTEME = """Tu rédiges une note réglementaire destinée aux instances de \
gouvernance d'une institution financière (comité d'audit, comité des risques, \
direction générale).

Règles éditoriales, non négociables :
- Chaque titre de slide est un MESSAGE, pas une étiquette. « Trois obligations \
nouvelles pèsent sur le dispositif LCB-FT » et non « Obligations ».
- Une idée par slide. Si deux idées, deux slides.
- Toute affirmation reposant sur un texte réglementaire cite sa source \
(référence, article, date).
- Tu ne paraphrases jamais un article de manière approximative : soit tu le \
cites verbatim dans une slide `reference`, soit tu en donnes la portée.
- Pas de superlatif, pas de formulation commerciale. Registre de note interne.
- Structure attendue : couverture, contexte, analyse d'impact, échéancier, \
recommandations.

Tu produis uniquement la structure de deck demandée."""


class DeckState(TypedDict, total=False):
    # Entrées
    demande: str
    contexte: str
    tenant: str
    dossier_sortie: str
    # État interne
    deck: Deck
    avertissements: Annotated[list[str], lambda a, b: b]
    iterations: int
    # Sortie
    chemin_pptx: str


def construire_graphe(llm: Any, themes_dir: Path | None = None):
    """`llm` : n'importe quel modèle LangChain supportant `with_structured_output`."""

    planificateur = llm.with_structured_output(Deck)

    def plan(state: DeckState) -> DeckState:
        messages = [
            ("system", PROMPT_SYSTEME),
            ("human", f"Demande :\n{state['demande']}\n\nContexte :\n{state.get('contexte', '')}"),
        ]
        if state.get("avertissements"):
            problemes = "\n".join(f"- {a}" for a in state["avertissements"])
            messages.append(
                (
                    "human",
                    "La version précédente présentait ces défauts de mise en page. "
                    "Reprends la structure en les corrigeant (scinder une slide, "
                    "raccourcir un libellé, réduire le nombre de points) sans "
                    "appauvrir le fond :\n" + problemes,
                )
            )
        deck = planificateur.invoke(messages)
        return {"deck": deck, "iterations": state.get("iterations", 0) + 1}

    def render(state: DeckState) -> DeckState:
        theme = Theme.charger(state.get("tenant", "default"), base_dir=themes_dir)
        dossier = Path(state.get("dossier_sortie", "/tmp/atlas-decks"))
        chemin = dossier / f"note-reglementaire-{state['deck'].entite[:20]}.pptx"
        resultat = render_deck(state["deck"], theme, chemin)
        return {
            "chemin_pptx": str(resultat.chemin),
            "avertissements": resultat.avertissements,
        }

    def qa(state: DeckState) -> DeckState:
        # Point d'extension : rendu PNG via LibreOffice + relecture visuelle par
        # un modèle vision. Les avertissements produits ici s'ajoutent simplement
        # à ceux du renderer et alimentent la même boucle.
        return {}

    def suite(state: DeckState) -> str:
        if state.get("avertissements") and state.get("iterations", 0) < MAX_ITERATIONS:
            return "plan"
        return END

    g = StateGraph(DeckState)
    g.add_node("plan", plan)
    g.add_node("render", render)
    g.add_node("qa", qa)
    g.add_edge(START, "plan")
    g.add_edge("plan", "render")
    g.add_edge("render", "qa")
    g.add_conditional_edges("qa", suite, {"plan": "plan", END: END})
    return g.compile()


# --------------------------------------------------------------------------
# Exposition en tant qu'outil pour un agent supérieur
# --------------------------------------------------------------------------


def outil_generer_note(llm: Any):
    """Retourne un tool LangChain que l'agent Atlas Guardian peut appeler."""
    from langchain_core.tools import tool

    graphe = construire_graphe(llm)

    @tool
    def generer_note_reglementaire(demande: str, contexte: str, tenant: str) -> str:
        """Génère une note réglementaire au format PowerPoint et retourne son chemin.

        demande : ce que la note doit démontrer.
        contexte : extraits réglementaires et éléments de situation de l'entité.
        tenant : identifiant du client, détermine la charte graphique.
        """
        etat = graphe.invoke(
            {
                "demande": demande,
                "contexte": contexte,
                "tenant": tenant,
                "dossier_sortie": os.getenv("ATLAS_DECK_DIR", "/tmp/atlas-decks"),
            }
        )
        return etat["chemin_pptx"]

    return generer_note_reglementaire
