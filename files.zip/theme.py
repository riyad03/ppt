"""Résolution du thème visuel.

Le style appartient au client de la plateforme, pas à Atlas Guardian : le
renderer ne connaît que des noms logiques (`primaire`, `accent`, `attenue`).
Ajouter un client = ajouter un YAML, jamais toucher au code.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml
from pptx.dml.color import RGBColor

THEMES_DIR = Path(__file__).parent / "themes"


def _rgb(hexa: str) -> RGBColor:
    return RGBColor.from_string(hexa.replace("#", "").upper())


@dataclass(frozen=True)
class Theme:
    nom: str
    police_titres: str
    police_texte: str
    couleurs: dict[str, RGBColor]
    criticite: dict[str, RGBColor]
    logo: Path | None
    pied_de_page: str | None

    def c(self, nom: str) -> RGBColor:
        return self.couleurs[nom]

    @classmethod
    def charger(cls, tenant: str = "default", base_dir: Path | None = None) -> "Theme":
        base = base_dir or THEMES_DIR
        chemin = base / f"{tenant}.yaml"
        if not chemin.exists():
            chemin = base / "default.yaml"
        data = yaml.safe_load(chemin.read_text(encoding="utf-8"))

        logo = data.get("logo")
        return cls(
            nom=data["nom"],
            police_titres=data["police"]["titres"],
            police_texte=data["police"]["texte"],
            couleurs={k: _rgb(v) for k, v in data["couleurs"].items()},
            criticite={k: _rgb(v) for k, v in data.get("criticite", {}).items()},
            logo=Path(logo) if logo else None,
            pied_de_page=data.get("pied_de_page"),
        )
