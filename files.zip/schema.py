"""Contrat de deck — la seule structure que le LLM a le droit de produire.

Les contraintes de longueur ne sont pas cosmétiques : elles garantissent que le
renderer n'aura jamais à gérer un débordement. Toute la discipline de mise en
page est portée ici, pas dans le prompt.
"""

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field

Criticite = Literal["Faible", "Moyenne", "Élevée"]


# --------------------------------------------------------------------------
# Types de slides (inventaire fermé — note réglementaire)
# --------------------------------------------------------------------------


class TitleSlide(BaseModel):
    """Couverture. Toujours la première slide, une seule par deck."""

    type: Literal["title"] = "title"
    titre: str = Field(max_length=80)
    sous_titre: str | None = Field(default=None, max_length=120)
    reference: str | None = Field(
        default=None, max_length=90, description="Texte réglementaire de rattachement"
    )


class SectionSlide(BaseModel):
    """Intercalaire de partie."""

    type: Literal["section"] = "section"
    numero: int = Field(ge=1, le=9)
    titre: str = Field(max_length=60)


class BulletsSlide(BaseModel):
    """Slide de fond : un message en titre, 2 à 5 points de démonstration."""

    type: Literal["bullets"] = "bullets"
    titre_action: str = Field(
        max_length=120,
        description="Le titre porte le message, pas l'étiquette. "
        "« Trois obligations nouvelles pèsent sur le dispositif LCB-FT » "
        "et non « Obligations ».",
    )
    points: list[Annotated[str, Field(max_length=200)]] = Field(
        min_length=2, max_length=5
    )
    source: str | None = Field(default=None, max_length=120)


class ReferenceSlide(BaseModel):
    """Extrait du texte réglementaire à gauche, lecture / interprétation à droite."""

    type: Literal["reference"] = "reference"
    titre_action: str = Field(max_length=120)
    reference: str = Field(
        max_length=110, description="Ex. « Circulaire BAM n° 5/W/2022, article 12 »"
    )
    extrait: str = Field(max_length=600, description="Citation du texte, verbatim")
    lecture: list[Annotated[str, Field(max_length=180)]] = Field(
        min_length=1, max_length=3, description="Ce que le texte implique concrètement"
    )


class ImpactRow(BaseModel):
    exigence: str = Field(max_length=90)
    impact: str = Field(max_length=140)
    entite: str = Field(max_length=40, description="Entité / fonction responsable")
    criticite: Criticite


class ImpactsSlide(BaseModel):
    """Tableau d'analyse d'impact — le cœur d'une note réglementaire."""

    type: Literal["impacts"] = "impacts"
    titre_action: str = Field(max_length=120)
    lignes: list[ImpactRow] = Field(min_length=2, max_length=6)
    source: str | None = Field(default=None, max_length=120)


class Kpi(BaseModel):
    valeur: str = Field(max_length=12, description="Ex. « 18 mois », « 3 », « 12 % »")
    libelle: str = Field(max_length=60)


class KpiSlide(BaseModel):
    """Chiffres clés (délais, volumétrie, seuils réglementaires)."""

    type: Literal["kpi"] = "kpi"
    titre_action: str = Field(max_length=120)
    kpis: list[Kpi] = Field(min_length=2, max_length=4)
    source: str | None = Field(default=None, max_length=120)


class Jalon(BaseModel):
    date: str = Field(max_length=24, description="Ex. « 31/12/2026 », « T2 2027 »")
    libelle: str = Field(max_length=90)


class TimelineSlide(BaseModel):
    """Échéancier de mise en conformité."""

    type: Literal["timeline"] = "timeline"
    titre_action: str = Field(max_length=120)
    jalons: list[Jalon] = Field(min_length=2, max_length=5)


class Recommandation(BaseModel):
    titre: str = Field(max_length=70)
    detail: str = Field(max_length=200)


class SyntheseSlide(BaseModel):
    """Recommandations numérotées. Ferme le deck."""

    type: Literal["synthese"] = "synthese"
    titre_action: str = Field(max_length=120)
    recommandations: list[Recommandation] = Field(min_length=2, max_length=4)


Slide = Union[
    TitleSlide,
    SectionSlide,
    BulletsSlide,
    ReferenceSlide,
    ImpactsSlide,
    KpiSlide,
    TimelineSlide,
    SyntheseSlide,
]


class Deck(BaseModel):
    """Le deck complet. C'est l'objet rendu par `llm.with_structured_output(Deck)`."""

    titre: str = Field(max_length=80)
    entite: str = Field(max_length=60, description="Institution destinataire")
    slides: list[Annotated[Slide, Field(discriminator="type")]] = Field(
        min_length=3, max_length=25
    )

    def model_post_init(self, __context) -> None:  # noqa: D105
        if self.slides and self.slides[0].type != "title":
            raise ValueError("La première slide doit être de type 'title'.")
