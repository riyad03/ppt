"""Test du renderer sans appel LLM — un deck construit à la main.

    python demo.py [chemin_sortie.pptx]
"""

import sys

from atlas_deck.renderer import render_deck
from atlas_deck.schema import (
    BulletsSlide,
    Deck,
    ImpactRow,
    ImpactsSlide,
    Jalon,
    Kpi,
    KpiSlide,
    Recommandation,
    ReferenceSlide,
    SectionSlide,
    SyntheseSlide,
    TimelineSlide,
    TitleSlide,
)
from atlas_deck.theme import Theme

deck = Deck(
    titre="Renforcement du dispositif de gestion du risque opérationnel",
    entite="Maghreb Universal Bank",
    slides=[
        TitleSlide(
            titre="Renforcement du dispositif de gestion du risque opérationnel",
            sous_titre="Analyse d'impact et trajectoire de mise en conformité",
            reference="Circulaire Bank Al-Maghrib n° 5/W/2022",
        ),
        SectionSlide(numero=1, titre="Ce que le texte change"),
        BulletsSlide(
            titre_action="Le texte déplace la charge de la preuve vers la première ligne de défense",
            points=[
                "Les métiers deviennent responsables de la collecte exhaustive des incidents, "
                "sans filtrage préalable par la fonction Risques.",
                "Le seuil de déclaration obligatoire est abaissé, ce qui élargit mécaniquement "
                "l'assiette des incidents à documenter.",
                "La fonction Risques conserve la validation méthodologique et la consolidation "
                "vers le régulateur.",
            ],
            source="Circulaire BAM n° 5/W/2022, articles 8 à 14",
        ),
        ReferenceSlide(
            titre_action="La notion d'incident significatif est désormais définie par des critères cumulatifs",
            reference="Circulaire BAM n° 5/W/2022, article 12",
            extrait=(
                "Est réputé significatif tout incident opérationnel dont la perte brute "
                "excède le seuil fixé par l'établissement, ou dont les effets affectent "
                "la continuité d'un service essentiel pendant plus de deux heures."
            ),
            lecture=[
                "Le seuil interne devient un paramètre réglementaire opposable, à faire valider "
                "par le comité des risques.",
                "La mesure de l'indisponibilité impose un horodatage fiable des incidents SI.",
            ],
        ),
        SectionSlide(numero=2, titre="Impacts sur le dispositif actuel"),
        ImpactsSlide(
            titre_action="Quatre chantiers conditionnent la conformité à l'échéance",
            lignes=[
                ImpactRow(
                    exigence="Collecte décentralisée",
                    impact="Désigner et former des correspondants incidents dans chaque métier",
                    entite="Risques / RH",
                    criticite="Élevée",
                ),
                ImpactRow(
                    exigence="Seuil de significativité",
                    impact="Faire valider le seuil interne par le comité des risques",
                    entite="Comité des risques",
                    criticite="Moyenne",
                ),
                ImpactRow(
                    exigence="Horodatage des incidents SI",
                    impact="Raccorder la supervision technique à la base incidents",
                    entite="DSI",
                    criticite="Élevée",
                ),
                ImpactRow(
                    exigence="Reporting régulateur",
                    impact="Adapter le format de remontée trimestrielle",
                    entite="Conformité",
                    criticite="Faible",
                ),
            ],
            source="Analyse BFS Consulting",
        ),
        KpiSlide(
            titre_action="L'effort porte d'abord sur la couverture organisationnelle",
            kpis=[
                Kpi(valeur="18", libelle="mois pour atteindre la conformité pleine"),
                Kpi(valeur="42", libelle="correspondants incidents à désigner"),
                Kpi(valeur="4", libelle="chantiers structurants"),
            ],
            source="Analyse BFS Consulting",
        ),
        TimelineSlide(
            titre_action="La trajectoire s'organise autour de quatre jalons de gouvernance",
            jalons=[
                Jalon(date="T4 2026", libelle="Validation du seuil par le comité des risques"),
                Jalon(date="T1 2027", libelle="Désignation et formation des correspondants"),
                Jalon(date="T3 2027", libelle="Raccordement de la supervision SI"),
                Jalon(date="T1 2028", libelle="Premier reporting au format cible"),
            ],
        ),
        SyntheseSlide(
            titre_action="Trois décisions sont attendues du comité des risques",
            recommandations=[
                Recommandation(
                    titre="Arrêter le seuil de significativité",
                    detail="Retenir un seuil aligné sur l'appétence au risque déjà approuvée, "
                    "et le documenter comme paramètre réglementaire opposable.",
                ),
                Recommandation(
                    titre="Mandater la DSI sur l'horodatage",
                    detail="Le raccordement de la supervision technique conditionne la mesure "
                    "de l'indisponibilité, donc la qualification des incidents.",
                ),
                Recommandation(
                    titre="Valider le calendrier de déploiement",
                    detail="La trajectoire proposée laisse six mois de marge avant l'échéance "
                    "réglementaire.",
                ),
            ],
        ),
    ],
)

if __name__ == "__main__":
    sortie = sys.argv[1] if len(sys.argv) > 1 else "demo-note-reglementaire.pptx"
    resultat = render_deck(deck, Theme.charger("default"), sortie)
    print(f"Fichier : {resultat.chemin}")
    if resultat.avertissements:
        print("Avertissements de mise en page :")
        for a in resultat.avertissements:
            print(f"  - {a}")
    else:
        print("Aucun avertissement de mise en page.")
