# atlas_deck — génération de notes réglementaires (.pptx) pour agent LangGraph

Module à brancher dans Atlas Guardian. Le LLM ne produit **jamais** de PPTX ni de XML :
il produit un objet `Deck` validé, que le renderer transforme en fichier de façon
déterministe.

```
atlas_deck/
├── schema.py            # contrat de deck (Pydantic) — 8 types de slides
├── renderer.py          # moteur de rendu python-pptx, un helper par type
├── theme.py             # résolution du thème par tenant
├── themes/default.yaml  # charte : un fichier par client
└── graph.py             # sous-graphe LangGraph : plan → render → qa
demo.py                  # deck d'exemple, sans appel LLM
```

## Installation

```bash
pip install python-pptx pydantic pyyaml langgraph langchain-core
python demo.py sortie.pptx      # vérifie la chaîne de rendu
```

## Les 8 types de slides

| Type | Usage dans une note réglementaire |
|---|---|
| `title` | Couverture — titre, sous-titre, texte réglementaire de rattachement |
| `section` | Intercalaire numéroté |
| `bullets` | Titre-message + 2 à 5 points |
| `reference` | Extrait verbatim du texte à gauche, lecture / portée à droite |
| `impacts` | Tableau exigence / impact / entité responsable / criticité |
| `kpi` | 2 à 4 chiffres clés (délais, volumétrie, seuils) |
| `timeline` | Échéancier de mise en conformité, 2 à 5 jalons |
| `synthese` | 2 à 4 recommandations numérotées — ferme le deck |

L'inventaire est **fermé**. Ajouter un type = ajouter un modèle dans `schema.py`,
un helper dans `renderer.py`, une entrée dans `_HELPERS`. Rien d'autre.

## Brancher dans le graphe

```python
from langchain_anthropic import ChatAnthropic
from atlas_deck.graph import construire_graphe, outil_generer_note

graphe = construire_graphe(ChatAnthropic(model="claude-sonnet-4-5"))
etat = graphe.invoke({
    "demande": "Note d'impact de la circulaire BAM 5/W/2022 sur le dispositif RO",
    "contexte": extraits_reglementaires + situation_entite,
    "tenant": "maghreb-universal-bank",
})
print(etat["chemin_pptx"])
```

Ou, pour l'exposer comme outil à l'agent principal :

```python
agent = create_react_agent(llm, tools=[outil_generer_note(llm), ...])
```

## Ajouter un client

Copier `themes/default.yaml` en `themes/<tenant>.yaml`, ajuster les couleurs et le
logo. Aucun code à modifier : le renderer ne connaît que des noms logiques
(`primaire`, `accent`, `attenue`, `fond_bloc`). En production, remplacer la lecture
disque par une lecture en base, la signature de `Theme.charger` ne change pas.

## Boucle qualité

`render_deck` retourne des avertissements de mise en page (titre trop long, slide
trop dense, cellule qui déborde) calculés à partir d'une estimation pessimiste de
la largeur des caractères en Arial. Le nœud `qa` les renvoie au planificateur, qui
reprend la structure — scinder une slide, raccourcir un libellé. Deux itérations
maximum, sinon le pipeline boucle sur des cas insolubles.

Pour ajouter la relecture visuelle dans le nœud `qa` :

```bash
soffice --headless --convert-to pdf deck.pptx
pdftoppm -jpeg -r 150 deck.pdf slide
```

puis passer les images à un modèle vision et concaténer ses remarques aux
avertissements existants. En SaaS, faire tourner LibreOffice dans un worker
séparé, jamais dans le process de l'API.

## Choix de conception à connaître

- **Pas de `.potx`.** Le style appartenant au client, un template par tenant serait
  ingérable ; la géométrie vient de la grille du renderer, les couleurs du YAML.
- **Arial partout**, disponible sur les postes des institutions financières. Le
  rendu LibreOffice utilise une substitution : contrôler sous PowerPoint avant
  livraison.
- **Contraintes de longueur dans le schéma.** C'est ce qui empêche les
  débordements, bien plus efficacement qu'une consigne dans le prompt.
- **Aucun filet décoratif, aucune bande de couleur.** Un seul accent, réservé aux
  chiffres clés, aux numéros de recommandation et à la criticité élevée.
