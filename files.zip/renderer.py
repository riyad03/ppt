"""Moteur de rendu déterministe. Aucun appel LLM ici.

Un helper par type de slide, une grille unique, toutes les couleurs et polices
issues du `Theme`. Chaque helper retourne la liste des avertissements de mise
en page (débordement estimé), remontés ensuite dans l'état du graphe.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

from .schema import (
    BulletsSlide,
    Deck,
    ImpactsSlide,
    KpiSlide,
    ReferenceSlide,
    SectionSlide,
    SyntheseSlide,
    TimelineSlide,
    TitleSlide,
)
from .theme import Theme

# --------------------------------------------------------------------------
# Grille — 16:9, 13.333" x 7.5". Toutes les valeurs en pouces.
# --------------------------------------------------------------------------
L_SLIDE, H_SLIDE = 13.333, 7.5
MARGE = 0.75
L_UTILE = L_SLIDE - 2 * MARGE
Y_TITRE = 0.62
H_TITRE = 0.95
Y_CONTENU = 1.85
Y_PIED = 6.95
H_CONTENU = Y_PIED - 0.25 - Y_CONTENU

PT_TITRE_COUV = 34
PT_TITRE = 21
PT_CORPS = 14
PT_PETIT = 11
PT_SOURCE = 9


@dataclass
class RenderResult:
    chemin: Path
    avertissements: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.avertissements


# --------------------------------------------------------------------------
# Primitives
# --------------------------------------------------------------------------


def _lignes_estimees(texte: str, largeur_in: float, pt: float) -> int:
    """Estimation du nombre de lignes après retour automatique.

    Approximation volontairement pessimiste (0.55 em de largeur moyenne en
    Arial) : mieux vaut un faux avertissement qu'un débordement en clientèle.
    """
    if not texte:
        return 0
    car_par_ligne = max(1, int(largeur_in * 72 / (pt * 0.55)))
    return max(1, math.ceil(len(texte) / car_par_ligne))


def _hauteur_estimee(texte: str, largeur_in: float, pt: float) -> float:
    return _lignes_estimees(texte, largeur_in, pt) * (pt * 1.28 / 72)


def _txt(
    slide,
    texte: str,
    x: float,
    y: float,
    w: float,
    h: float,
    *,
    pt: int,
    couleur: RGBColor,
    police: str,
    gras: bool = False,
    align=PP_ALIGN.LEFT,
    ancre=MSO_ANCHOR.TOP,
    interligne: float = 1.15,
):
    boite = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    cadre = boite.text_frame
    cadre.word_wrap = True
    cadre.vertical_anchor = ancre
    cadre.margin_left = cadre.margin_right = 0
    cadre.margin_top = cadre.margin_bottom = 0
    p = cadre.paragraphs[0]
    p.alignment = align
    p.line_spacing = interligne
    run = p.add_run()
    run.text = texte
    run.font.name = police
    run.font.size = Pt(pt)
    run.font.bold = gras
    run.font.color.rgb = couleur
    return boite


def _rect(slide, x, y, w, h, couleur: RGBColor, forme=MSO_SHAPE.RECTANGLE):
    f = slide.shapes.add_shape(forme, Inches(x), Inches(y), Inches(w), Inches(h))
    f.fill.solid()
    f.fill.fore_color.rgb = couleur
    f.line.fill.background()
    f.shadow.inherit = False
    return f


def _slide_vierge(prs: Presentation, theme: Theme, fond: str = "fond"):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    fond_shape = slide.background.fill
    fond_shape.solid()
    fond_shape.fore_color.rgb = theme.c(fond)
    return slide


def _titre_action(slide, texte: str, theme: Theme) -> list[str]:
    _txt(
        slide,
        texte,
        MARGE,
        Y_TITRE,
        L_UTILE,
        H_TITRE,
        pt=PT_TITRE,
        couleur=theme.c("primaire"),
        police=theme.police_titres,
        gras=True,
        ancre=MSO_ANCHOR.TOP,
    )
    if _hauteur_estimee(texte, L_UTILE, PT_TITRE) > H_TITRE:
        return [f"Titre trop long, déborde sur le contenu : « {texte[:60]}… »"]
    return []


def _pied(slide, theme: Theme, numero: int):
    if theme.pied_de_page:
        _txt(
            slide,
            theme.pied_de_page,
            MARGE,
            Y_PIED,
            L_UTILE - 1,
            0.28,
            pt=PT_SOURCE,
            couleur=theme.c("attenue"),
            police=theme.police_texte,
        )
    _txt(
        slide,
        str(numero),
        L_SLIDE - MARGE - 0.6,
        Y_PIED,
        0.6,
        0.28,
        pt=PT_SOURCE,
        couleur=theme.c("attenue"),
        police=theme.police_texte,
        align=PP_ALIGN.RIGHT,
    )


def _source(slide, texte: str | None, theme: Theme):
    if not texte:
        return
    _txt(
        slide,
        f"Source : {texte}",
        MARGE,
        Y_PIED - 0.42,
        L_UTILE,
        0.3,
        pt=PT_SOURCE,
        couleur=theme.c("attenue"),
        police=theme.police_texte,
    )


# --------------------------------------------------------------------------
# Helpers par type de slide
# --------------------------------------------------------------------------


def _rendre_title(prs, s: TitleSlide, theme: Theme, deck: Deck, num: int) -> list[str]:
    slide = _slide_vierge(prs, theme)
    y = 2.6
    _txt(
        slide,
        s.titre,
        MARGE,
        y,
        L_UTILE - 2,
        1.6,
        pt=PT_TITRE_COUV,
        couleur=theme.c("primaire"),
        police=theme.police_titres,
        gras=True,
        interligne=1.1,
    )
    y += _hauteur_estimee(s.titre, L_UTILE - 2, PT_TITRE_COUV) + 0.25
    if s.sous_titre:
        _txt(
            slide, s.sous_titre, MARGE, y, L_UTILE - 2, 0.5,
            pt=16, couleur=theme.c("texte"), police=theme.police_texte,
        )
        y += 0.55
    if s.reference:
        _txt(
            slide, s.reference, MARGE, y, L_UTILE - 2, 0.4,
            pt=PT_PETIT, couleur=theme.c("attenue"), police=theme.police_texte,
        )
    _txt(
        slide, deck.entite, MARGE, Y_PIED - 0.1, L_UTILE, 0.35,
        pt=PT_PETIT, couleur=theme.c("attenue"), police=theme.police_texte,
    )
    if theme.logo and theme.logo.exists():
        slide.shapes.add_picture(
            str(theme.logo), Inches(L_SLIDE - MARGE - 1.6), Inches(MARGE), height=Inches(0.55)
        )
    return []


def _rendre_section(prs, s: SectionSlide, theme: Theme, deck: Deck, num: int) -> list[str]:
    slide = _slide_vierge(prs, theme, fond="fond_section")
    _txt(
        slide, f"{s.numero:02d}", MARGE, 2.7, 2.0, 1.0,
        pt=40, couleur=theme.c("fond"), police=theme.police_titres, gras=True,
    )
    _txt(
        slide, s.titre, MARGE, 3.65, L_UTILE - 1.5, 1.2,
        pt=28, couleur=theme.c("fond"), police=theme.police_titres, gras=True,
    )
    return []


def _rendre_bullets(prs, s: BulletsSlide, theme: Theme, deck: Deck, num: int) -> list[str]:
    slide = _slide_vierge(prs, theme)
    avert = _titre_action(slide, s.titre_action, theme)
    _pied(slide, theme, num)
    _source(slide, s.source, theme)

    x_puce, x_texte = MARGE, MARGE + 0.32
    larg = L_UTILE - 0.32
    y = Y_CONTENU
    for point in s.points:
        h = _hauteur_estimee(point, larg, PT_CORPS)
        _rect(slide, x_puce, y + 0.09, 0.1, 0.1, theme.c("primaire"))
        _txt(
            slide, point, x_texte, y, larg, h + 0.1,
            pt=PT_CORPS, couleur=theme.c("texte"), police=theme.police_texte,
        )
        y += h + 0.30
    if y > Y_CONTENU + H_CONTENU:
        avert.append(
            f"Contenu trop dense sur « {s.titre_action[:50]}… » : "
            f"{len(s.points)} points, scinder la slide."
        )
    return avert


def _rendre_reference(prs, s: ReferenceSlide, theme: Theme, deck: Deck, num: int) -> list[str]:
    slide = _slide_vierge(prs, theme)
    avert = _titre_action(slide, s.titre_action, theme)
    _pied(slide, theme, num)

    l_col = (L_UTILE - 0.6) / 2
    x_droite = MARGE + l_col + 0.6

    # Colonne gauche : le texte réglementaire, dans un bloc en retrait.
    h_bloc = min(H_CONTENU, _hauteur_estimee(s.extrait, l_col - 0.6, PT_PETIT) + 1.25)
    _rect(slide, MARGE, Y_CONTENU, l_col, h_bloc, theme.c("fond_bloc"))
    _txt(
        slide, s.reference, MARGE + 0.3, Y_CONTENU + 0.28, l_col - 0.6, 0.5,
        pt=PT_PETIT, couleur=theme.c("primaire"), police=theme.police_texte, gras=True,
    )
    _txt(
        slide, f"« {s.extrait} »", MARGE + 0.3, Y_CONTENU + 0.85,
        l_col - 0.6, h_bloc - 1.1,
        pt=PT_PETIT, couleur=theme.c("texte"), police=theme.police_texte,
    )
    if h_bloc >= H_CONTENU:
        avert.append("Extrait réglementaire trop long pour la colonne de gauche.")

    # Colonne droite : la lecture.
    _txt(
        slide, "Lecture", x_droite, Y_CONTENU, l_col, 0.35,
        pt=PT_PETIT, couleur=theme.c("attenue"), police=theme.police_texte, gras=True,
    )
    y = Y_CONTENU + 0.5
    for point in s.lecture:
        h = _hauteur_estimee(point, l_col - 0.32, PT_CORPS)
        _rect(slide, x_droite, y + 0.09, 0.1, 0.1, theme.c("primaire"))
        _txt(
            slide, point, x_droite + 0.32, y, l_col - 0.32, h + 0.1,
            pt=PT_CORPS, couleur=theme.c("texte"), police=theme.police_texte,
        )
        y += h + 0.30
    return avert


def _rendre_impacts(prs, s: ImpactsSlide, theme: Theme, deck: Deck, num: int) -> list[str]:
    slide = _slide_vierge(prs, theme)
    avert = _titre_action(slide, s.titre_action, theme)
    _pied(slide, theme, num)
    _source(slide, s.source, theme)

    entetes = ["Exigence", "Impact", "Entité", "Criticité"]
    largeurs = [3.2, 5.2, 1.9, 1.5]
    n_lignes = len(s.lignes) + 1
    h_ligne = 0.52
    tableau = slide.shapes.add_table(
        n_lignes, 4, Inches(MARGE), Inches(Y_CONTENU),
        Inches(sum(largeurs)), Inches(h_ligne * n_lignes),
    ).table
    tableau.first_row = True
    for i, l in enumerate(largeurs):
        tableau.columns[i].width = Inches(l)

    for j, entete in enumerate(entetes):
        cell = tableau.cell(0, j)
        cell.text = entete
        cell.fill.solid()
        cell.fill.fore_color.rgb = theme.c("primaire")
        _styler_cellule(cell, theme, PT_PETIT, theme.c("fond"), gras=True)

    for i, ligne in enumerate(s.lignes, start=1):
        valeurs = [ligne.exigence, ligne.impact, ligne.entite, ligne.criticite]
        for j, valeur in enumerate(valeurs):
            cell = tableau.cell(i, j)
            cell.text = valeur
            cell.fill.solid()
            cell.fill.fore_color.rgb = theme.c("fond") if i % 2 else theme.c("fond_bloc")
            couleur = (
                theme.criticite.get(ligne.criticite, theme.c("texte"))
                if j == 3
                else theme.c("texte")
            )
            _styler_cellule(cell, theme, PT_PETIT, couleur, gras=(j == 3))
            if _hauteur_estimee(valeur, largeurs[j] - 0.2, PT_PETIT) > h_ligne - 0.12:
                avert.append(
                    f"Cellule trop longue (ligne {i}, colonne « {entetes[j]} »)."
                )
    return avert


def _styler_cellule(cell, theme: Theme, pt: int, couleur: RGBColor, gras=False):
    cell.margin_left = cell.margin_right = Inches(0.1)
    cell.margin_top = cell.margin_bottom = Inches(0.06)
    cell.vertical_anchor = MSO_ANCHOR.MIDDLE
    for p in cell.text_frame.paragraphs:
        for run in p.runs:
            run.font.name = theme.police_texte
            run.font.size = Pt(pt)
            run.font.bold = gras
            run.font.color.rgb = couleur


def _rendre_kpi(prs, s: KpiSlide, theme: Theme, deck: Deck, num: int) -> list[str]:
    slide = _slide_vierge(prs, theme)
    avert = _titre_action(slide, s.titre_action, theme)
    _pied(slide, theme, num)
    _source(slide, s.source, theme)

    n = len(s.kpis)
    ecart = 0.5
    larg = (L_UTILE - ecart * (n - 1)) / n
    y = Y_CONTENU + 0.7
    for i, kpi in enumerate(s.kpis):
        x = MARGE + i * (larg + ecart)
        _txt(
            slide, kpi.valeur, x, y, larg, 1.1,
            pt=48, couleur=theme.c("accent"), police=theme.police_titres, gras=True,
        )
        _txt(
            slide, kpi.libelle, x, y + 1.2, larg, 0.9,
            pt=PT_CORPS, couleur=theme.c("texte"), police=theme.police_texte,
        )
        if len(kpi.valeur) > 8:
            avert.append(f"Chiffre clé trop long pour la colonne : « {kpi.valeur} ».")
    return avert


def _rendre_timeline(prs, s: TimelineSlide, theme: Theme, deck: Deck, num: int) -> list[str]:
    slide = _slide_vierge(prs, theme)
    avert = _titre_action(slide, s.titre_action, theme)
    _pied(slide, theme, num)

    n = len(s.jalons)
    y_axe = Y_CONTENU + 1.35
    larg = L_UTILE / n
    _rect(slide, MARGE, y_axe, L_UTILE, 0.02, theme.c("filet"))
    for i, jalon in enumerate(s.jalons):
        x = MARGE + i * larg
        cx = x + larg / 2
        _rect(slide, cx - 0.09, y_axe - 0.08, 0.18, 0.18, theme.c("primaire"), MSO_SHAPE.OVAL)
        _txt(
            slide, jalon.date, x, y_axe - 0.75, larg, 0.4,
            pt=PT_CORPS, couleur=theme.c("primaire"), police=theme.police_titres,
            gras=True, align=PP_ALIGN.CENTER,
        )
        _txt(
            slide, jalon.libelle, x + 0.15, y_axe + 0.35, larg - 0.3, 1.4,
            pt=PT_PETIT, couleur=theme.c("texte"), police=theme.police_texte,
            align=PP_ALIGN.CENTER,
        )
        if _hauteur_estimee(jalon.libelle, larg - 0.3, PT_PETIT) > 1.4:
            avert.append(f"Libellé de jalon trop long : « {jalon.libelle[:40]}… ».")
    return avert


def _rendre_synthese(prs, s: SyntheseSlide, theme: Theme, deck: Deck, num: int) -> list[str]:
    slide = _slide_vierge(prs, theme)
    avert = _titre_action(slide, s.titre_action, theme)
    _pied(slide, theme, num)

    y = Y_CONTENU
    for i, reco in enumerate(s.recommandations, start=1):
        h_detail = _hauteur_estimee(reco.detail, L_UTILE - 0.85, PT_CORPS)
        _txt(
            slide, str(i), MARGE, y - 0.05, 0.6, 0.6,
            pt=24, couleur=theme.c("accent"), police=theme.police_titres, gras=True,
        )
        _txt(
            slide, reco.titre, MARGE + 0.65, y, L_UTILE - 0.85, 0.35,
            pt=PT_CORPS + 1, couleur=theme.c("primaire"),
            police=theme.police_titres, gras=True,
        )
        _txt(
            slide, reco.detail, MARGE + 0.65, y + 0.38, L_UTILE - 0.85, h_detail + 0.1,
            pt=PT_CORPS, couleur=theme.c("texte"), police=theme.police_texte,
        )
        y += 0.38 + h_detail + 0.45
    if y > Y_CONTENU + H_CONTENU:
        avert.append("Slide de synthèse trop dense : réduire à 3 recommandations.")
    return avert


_HELPERS = {
    "title": _rendre_title,
    "section": _rendre_section,
    "bullets": _rendre_bullets,
    "reference": _rendre_reference,
    "impacts": _rendre_impacts,
    "kpi": _rendre_kpi,
    "timeline": _rendre_timeline,
    "synthese": _rendre_synthese,
}


def render_deck(deck: Deck, theme: Theme, chemin_sortie: str | Path) -> RenderResult:
    """Rend le deck en .pptx. Déterministe : mêmes entrées, même fichier."""
    prs = Presentation()
    prs.slide_width = Inches(L_SLIDE)
    prs.slide_height = Inches(H_SLIDE)

    avertissements: list[str] = []
    for numero, s in enumerate(deck.slides, start=1):
        avertissements += _HELPERS[s.type](prs, s, theme, deck, numero)

    chemin = Path(chemin_sortie)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(chemin))
    return RenderResult(chemin=chemin, avertissements=avertissements)
